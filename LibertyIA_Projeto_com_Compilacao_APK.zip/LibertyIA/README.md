# Liberty IA — projeto Android inicial

Este é o projeto Android anterior da Liberty IA. Mantém a identidade visual escura/futurista e sem cruz.

## O que já existe
- Aplicativo Android em Kotlin com tela inicial.
- Campo de mensagem e botão de envio.
- Resposta local de demonstração para testar a interface.
- Estrutura visual preparada para evoluir com recursos de voz, imagens, documentos e pesquisa.

## Estado atual
**Este pacote ainda não é um APK instalável.** O chat atual é uma demonstração local; ele ainda não está ligado a um modelo de inteligência artificial real.

## Como gerar o APK no Android Studio
1. Copie o ZIP para um computador com Android Studio instalado.
2. Extraia o ZIP.
3. No Android Studio, escolha **Open** e selecione a pasta `LibertyIA` (a pasta que contém `settings.gradle`).
4. Aguarde o Gradle sincronizar e resolva eventuais atualizações solicitadas pelo Android Studio.
5. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Quando a compilação terminar, use o aviso **locate** para encontrar o APK de teste.

## Para transformar o chat em IA real
A próxima etapa é conectar o aplicativo a um backend seguro que chame um provedor de IA. Não coloque uma chave secreta de API diretamente no código do APK, pois ela pode ser extraída. A conexão pode ter custos de uso conforme o provedor escolhido.

## Ambiente de compilação
Este pacote foi revisado neste ambiente, mas aqui não há Android Studio, Android SDK nem Gradle instalado; por isso não foi possível compilar ou validar um APK nesta sessão.
