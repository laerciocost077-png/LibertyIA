package com.libertyia.app

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val message = findViewById<EditText>(R.id.message)
        val send = findViewById<Button>(R.id.send)
        val status = findViewById<TextView>(R.id.status)

        send.setOnClickListener {
            val text = message.text.toString().trim()
            status.text = if (text.isEmpty()) {
                "Digite uma mensagem para começar."
            } else {
                "Você disse:\n\n$text\n\nA Liberty IA está pronta para receber o motor de IA."
            }
            message.text.clear()
        }
    }
}
